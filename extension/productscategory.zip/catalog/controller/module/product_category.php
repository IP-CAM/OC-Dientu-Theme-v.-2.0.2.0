<?php
class ControllerModuleProductCategory extends Controller {
	public function index($setting) {
		$this->load->language('module/product_category');

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_tax'] = $this->language->get('text_tax');

		$data['button_cart'] = $this->language->get('button_cart');
		$data['button_wishlist'] = $this->language->get('button_wishlist');
		$data['button_compare'] = $this->language->get('button_compare');

		$this->load->model('catalog/category');
		$this->load->model('catalog/product');
		$this->load->model('tool/image');

		$data['products'] = array();

		if (empty($setting['limit'])) {
			$setting['limit'] = 12;
		}
		
	
		
		$categories = array_slice($setting['product_category_module'], 0,12);
		
		$k = 0;
		
		foreach ($categories as $category) {
			
			$products = $this->model_catalog_product->getProducts(array('filter_category_id' => $category['category'], 'start' => 0, 'limit' => $setting['limit']));
			
			foreach($products as $i => $product_info)
			{
				
				if ($product_info) {
					
					
			
					if ($product_info['image']) {
						$image = $this->model_tool_image->resize($product_info['image'], $category['width'], $category['height']);
					} else {
						$image = $this->model_tool_image->resize('placeholder.png', $category['width'], $category['height']);
					}
	
					if (($this->config->get('config_customer_price') && $this->customer->isLogged()) || !$this->config->get('config_customer_price')) {
						$price = $this->currency->format($this->tax->calculate($product_info['price'], $product_info['tax_class_id'], $this->config->get('config_tax')));
					} else {
						$price = false;
					}
	
					if ((float)$product_info['special']) {
						$special = $this->currency->format($this->tax->calculate($product_info['special'], $product_info['tax_class_id'], $this->config->get('config_tax')));
					} else {
						$special = false;
					}
	
					if ($this->config->get('config_tax')) {
						$tax = $this->currency->format((float)$product_info['special'] ? $product_info['special'] : $product_info['price']);
					} else {
						$tax = false;
					}
	
					if ($this->config->get('config_review_status')) {
						$rating = $product_info['rating'];
					} else {
						$rating = false;
					}
					
					
			
			$language_id = $this->config->get('config_language_id');
			
			$data['button_cart_disabled'] = $this->language->get('button_cart_disabled');
					
					if ($category['limit']) {
						$limit = $category['limit'];
					} else {
						$limit = 12;
					}
					
	
					$data['products'][$k][] = array(
						'title'       => $category['name'],
						'limit'       => $limit,
						'product_id'  => $product_info['product_id'],
						'thumb'       => $image,
						'name'        => $product_info['name'],
						'description' => utf8_substr(strip_tags(html_entity_decode($product_info['description'], ENT_QUOTES, 'UTF-8')), 0, $this->config->get('config_product_description_length')) . '..',
						'price'       => $price,
						'special'     => $special,
						'tax'         => $tax,
						'rating'      => $rating,
						'href'        => $this->url->link('product/product', 'product_id=' . $product_info['product_id'])
					);
				}
			}
			
			$k++;
		}
		
		//var_dump($data['products']);die;

		if ($data['products']) {
			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/product_category.tpl')) {
				return $this->load->view($this->config->get('config_template') . '/template/module/product_category.tpl', $data);
			} else {
				return $this->load->view('default/template/module/product_category.tpl', $data);
			}
		}
	}
}