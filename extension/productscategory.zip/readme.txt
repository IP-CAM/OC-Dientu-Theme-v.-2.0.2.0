This module display product by category selected on admin page, just like lastest product, but separated by your own category.

DEMO: http://open.setbenson.com

*** Don't forget to backup your files ***

Just extract and put in to the root of your opencart installation and go to admin and enable the module.
Set your fields especially layout field (set it to home).

Hope this module helps!

If you found some errors, drop me a message
If you like this module, please rate it. Thanks

contact me @ http://fb.com/cvanilac