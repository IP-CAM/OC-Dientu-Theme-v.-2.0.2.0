<?php
// Heading
$_['heading_title'] = 'Category Products';

// Text
$_['text_tax']      = 'Ex Tax:';